
public interface Evaluation {
    double evaluate(); 
    char grade(double evaluate);     
}