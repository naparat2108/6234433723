
import java.util.ArrayList;

public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new ArrayList<>();
        arr.add(new Hybrid(45,1200000,600,150,1));
        arr.add(new CNGBus(50,1000000,200,2));
        arr.stream().map((b) -> {
            System.out.println("ID: "+b.getID());
            return b;
        }).map((b) -> {
            if(b instanceof Hybrid){
                Hybrid hy = (Hybrid) b;
                System.out.println("Emission Tier: "+hy.getEmissionTier()+"\nAccel: "+hy.getAccel());
            }
            return b;
        }).filter((b) -> (b instanceof CNGBus)).map((b) -> (CNGBus) b).forEachOrdered((cng) -> {
            System.out.println("Emission Tier: "+cng.getEmissionTier()+"\nAccel: "+cng.getAccel());
        });
    }
}