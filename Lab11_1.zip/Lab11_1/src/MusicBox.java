import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    ArrayList<Object> msc = new ArrayList<>();
    
    @Override
    public void enqueue(Object o) {
        msc.add(o);
        System.out.println(o+" is added in queue");
    }

    @Override
    public void dequeue() {
        System.out.println("Now playing "+msc.get(0));
        msc.remove(0);
    }
    
}