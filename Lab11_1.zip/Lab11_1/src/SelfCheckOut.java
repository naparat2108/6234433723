import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    private double total;
    ArrayList<Product> product;

    public SelfCheckOut() {
        this.product = new ArrayList<>();
    }
    
    @Override
    public void enqueue(Object o){
        Product p = (Product) o;
        product.add(p);
        System.out.println(p.getName()+" is added in queue");
    }

    @Override
    public void dequeue(){
        total= total + product.get(0).getPrice();
        product.remove(0);
    }
    
    public double getAmount(){
        return total;
    }
}