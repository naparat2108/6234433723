
package lab12_1;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Lab12_1 {
    
    public static void main(String[] args) throws FileNotFoundException {

        String string = "";
        Scanner scanner = new Scanner(System.in);
        boolean firstLine = true;
        int l_cnt = 0;
        int w_cnt = 0;
        int ch_cnt = 0;

        System.out.println("Start typing (type quit to exit): ");

        while (true) {
            String line = scanner.nextLine();
            if (line.equals("quit")) {
                break;
            }
            else {
                if (!firstLine) {
                    string = string + "\n";
                    string = string + line;
                }
                else {
                    string += line;
                    firstLine = false;
                }
            }
        }

        File file = new File("output.txt");
        PrintWriter output = new PrintWriter(file);
        output.print(string);
        output.close();

        Scanner read = new Scanner(file);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            l_cnt++;
            String[] words = line.split(" ");
            w_cnt = w_cnt + words.length;
            ch_cnt = ch_cnt + line.length();
        }
        read.close();
        System.out.print("Total characters : ");
        System.out.println(ch_cnt);
        System.out.print("Total words : ");
        System.out.println(w_cnt);
        System.out.print("Total lines : ");
        System.out.println(l_cnt);
    }
}
