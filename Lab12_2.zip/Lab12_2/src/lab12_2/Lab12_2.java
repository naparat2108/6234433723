
package lab12_2;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Lab12_2 {

    public static void main(String[] args) {
        File file = new File("wordlist.txt");
        ArrayList<String> wordlst = new ArrayList<>();
        try{
            Scanner readFile = new Scanner(file);
            while (readFile.hasNextLine()) {
                String line = readFile.nextLine();
                wordlst.add(line);
            }
        }catch (FileNotFoundException e){
            System.out.println(e);
        }
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String text = sc.nextLine();
        String[] word = text.split(" ");
        boolean containAll = true;
        System.out.println("Words not contained:");
        for(int i=0;i<=word.length-1;i++)
            if(!wordlst.contains(word[i])){
                System.out.println(word[i]);
                containAll=false;
            }
        if(containAll)
            System.out.println("N/A");
    }
}
