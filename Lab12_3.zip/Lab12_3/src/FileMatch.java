
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;
import java.io.IOException;
import java.io.RandomAccessFile;

public class FileMatch {
    
    public static void main(String[] args) throws Exception{
        ArrayList<AccountRecord> acctRec = new ArrayList<>();
        ArrayList<TransactionRecord> TranRec = new ArrayList<>();
        File file = new File("master.txt");
        File file1= new File("trans.txt");
        try(Scanner readfile = new Scanner(file);){
            while(readfile.hasNextLine()){
                String[] ac = readfile.nextLine().split("\\s");
                AccountRecord ar = new AccountRecord(Integer.parseInt(ac[0]),ac[1]+" "+ac[2],Double.parseDouble(ac[3]));
                acctRec.add(ar);
            }
        } catch(IOException e){
        }
        try(Scanner readfile1 = new Scanner(file1);){
            while(readfile1.hasNextLine()){
                
                String[] ac = readfile1.nextLine().split("\\s");
                TransactionRecord tr = new TransactionRecord(Integer.parseInt(ac[0]),Double.parseDouble(ac[1]));
                TranRec.add(tr);
            }
        } catch(IOException e){
        }
        
        for(int i=0;i<acctRec.size();i++){
            for(int j=0;j<TranRec.size();j++){
                acctRec.get(i).conbine(TranRec.get(j));
            }
        }

        String name;
        int AccNo;
        double Balance;
        int Tcnt;
        double all_balance=0;
        int cntNottrans=0;
        int accCnt=0;
           try{
               RandomAccessFile file2 = new RandomAccessFile("newMaster.dat","rw");
               for(int i=0;i<acctRec.size();i++){
                   name = acctRec.get(i).getName();
                   AccNo = acctRec.get(i).getAcctNo();
                   Balance = acctRec.get(i).getBalance();
                   Tcnt = acctRec.get(i).getTransCnt();
                   file2.writeInt(AccNo);
                   while(name.length()<30){
                       name+=' ';
                   }
                   String sentence = name;
                   file2.writeChars(sentence);
                   file2.writeDouble(Balance);
                   file2.writeInt(Tcnt);
                   file2.writeChar('\n');
               }
               file2.seek(0);
           } catch(IOException e){
           }
        try{
            RandomAccessFile file3 = new RandomAccessFile("newMaster.dat","r");
            
            for (AccountRecord acctRec1 : acctRec) {
                file3.seek(file3.getFilePointer()+64);
                all_balance+=file3.readDouble();
                if(file3.readInt() == 0){cntNottrans++;}
                accCnt++;
                file3.seek(file3.getFilePointer()+2);
            }

        } catch (IOException ex){
        } 
        System.out.println("Total Account Record : "+accCnt);
        System.out.println("Total Balance : "+all_balance);
        System.out.println("No transaction : "+cntNottrans+" account.");
    }   
}