
public class TransactionRecord {
    
    private int acctNo;
    private double amtTran;
    
    public TransactionRecord(int acctNo,double amtTran){
        this.acctNo=acctNo;
        this.amtTran=amtTran;
    }
    
    public void setAcctNo(int number){
        acctNo=number;
    }
    
    public void setAmtTran(int number){
        amtTran=number;
    }
    
    public int getAcctNo(){
        return acctNo;
    }
    
    public double getAmtTran(){
        return amtTran;
    }
}