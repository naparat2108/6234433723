public class HollePrintor {
 
    public static void main(String[] args) {
    
    String s0 = "Hello, World!";
    String rs = s0.replace('e','O');
    rs = rs.replace('o','e');
    rs = rs.replace('O','o');        
    System.out.println(rs); 
    }
}
