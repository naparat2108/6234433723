import java.util.Calendar; 
import java.util.GregorianCalendar; 

public class Lab2_3 {

    public static void main(String[] args) {
        GregorianCalendar cal = new GregorianCalendar();
        GregorianCalendar myBirthday = new GregorianCalendar(2000,Calendar.AUGUST, 21);
        cal.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); 
        int month = cal.get(Calendar.MONTH)+1;
        int year = cal.get(Calendar.YEAR);
        int weekday1 = myBirthday.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth1 = myBirthday.get(Calendar.DAY_OF_MONTH); 
        int month1 = myBirthday.get(Calendar.MONTH)+1;
        int year1 = myBirthday.get(Calendar.YEAR);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
        System.out.println(weekday1+" "+dayOfMonth1+" "+month1+" "+year1);
    }
}
