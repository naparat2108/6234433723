public class InsectPopulation {
    
    private double insectnum;   
    
    public InsectPopulation(double num){
        insectnum = num;
    }
    
    public void breed(){
        insectnum = insectnum*2;
    }
    
    public void spray(){
        insectnum = insectnum*0.9;
    }  
    
    public double getNumInsect(){
        return insectnum;
    }
    
}

