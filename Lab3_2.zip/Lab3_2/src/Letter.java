public class Letter {
    public String sender;
    public String receiver;
    public String text="";

    public Letter(String from, String to){
        sender = "Dear "+from+":";
        receiver = "\nSincerely,\n\n"+to;
    }
    public void addLine(String line){
        text = "\n"+text+line+"\n";
    }
    public String getText(){
        return sender+text+receiver;
    }
    
}
