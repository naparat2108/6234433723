public class SodaCan {
    private double diameter;
    private double height;
    private double volume;
    private double radius;
    private double sur_area;
    
    public SodaCan(double d,double h){
        radius = d/2;
        height = h;
    } 
    public double getVolume(){
        volume = (radius*radius)*height*(3.14159265359);
        return volume;
    }
    
    public double getSurfaceArea(){
        sur_area = 2*radius*height*(3.14159265359)+2*radius*radius*(3.14159265359);
        return sur_area;
    }
    
}
