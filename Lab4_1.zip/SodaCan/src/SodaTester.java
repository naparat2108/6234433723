import java.util.Scanner;
public class SodaTester {
    
    public static void main(String[] args) {
        
        Scanner value = new Scanner(System.in);
        System.out.print("Enter height: ");
        Double h = value.nextDouble();
        System.out.print("Enter Enter diameter: ");
        Double d = value.nextDouble();
        SodaCan soda_can = new SodaCan(d,h);
        System.out.printf("Volume: %.2f\n",soda_can.getVolume());
        System.out.printf("Surface area: %.2f\n",soda_can.getSurfaceArea());
    }
    
}
