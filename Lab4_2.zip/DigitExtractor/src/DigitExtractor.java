public class DigitExtractor {
    private int num;
    private int n;
    
    public DigitExtractor(int anInteger){
        num = anInteger;   
    }
    public int nextDigit() {
        n = num%10;
        num = num/10;
        return n;
    }
    
}
