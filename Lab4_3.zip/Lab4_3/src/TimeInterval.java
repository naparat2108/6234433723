public class TimeInterval {
    private int h_start;
    private int h_end;

    public TimeInterval(int start,int end){
        h_start = start;
        h_end = end;
    }
    public double getHours(){
        int hours = h_end - h_start;
        hours = hours/100;
        return hours;
    }
    public double getMinutes(int start,int end){
        int minutes = (end/100*60+end%100)-(start/100*60+start%100);
        minutes = minutes%60;
        return minutes;
    }
}
    
