
import java.util.Scanner;

public class TimeIntervalTester {
    public static void main(String[] args) {
        Scanner stare_end = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = stare_end.nextInt();
        System.out.print("Enter end time: ");
        int end = stare_end.nextInt();
        TimeInterval time = new TimeInterval(start,end);
        System.out.println((int)time.getHours()+" hours "+(int)time.getMinutes(start,end)+" minutes");
    }
}
