public class Zeller {
    private final int dayOfMonth; 
    private final int month; 
    private int year;
    private int h,q,m,k,j;

    public Zeller(int year,int month,int day){
        this.dayOfMonth = day;
        this.month = month;
        this.year = year;
    }
    enum Day{
        SUNDAY("Sunday"),MONDAY("Monday"),TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),THURSDAY("Thursday"),FRIDAY("Friday"),SATURDAY("Saturday");
        private final String dayOut1; 
        Day (String dayOut){
            this.dayOut1 = dayOut;
        }
        public String get_Day(){
                return dayOut1;
        }
    }
    public Day getDayOfWeek(){
        q = dayOfMonth;
        m = month;
        if (m == 1){year -= 1;m = 13;}
        if (m == 2){year -= 1;m = 14;}
        j = year/100;
        k = year%100;
        Day getDay = Day.SUNDAY;
        h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(j*5))%7;
        switch(h)
        {
            case 0: getDay =Day.SATURDAY; break;
            case 1: getDay =Day.SUNDAY; break;
            case 2: getDay =Day.MONDAY; break;
            case 3: getDay =Day.TUESDAY; break;
            case 4: getDay =Day.WEDNESDAY; break;
            case 5: getDay =Day.THURSDAY; break;
            case 6: getDay =Day.FRIDAY; break; 
        }
        return getDay;
    } 
}

