package com.fam.guessanumber;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecActivity extends AppCompatActivity{
    int rnd2;
    int rnd;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.second_activity);
            rnd = getIntent().getIntExtra("ran",rnd2);

            final TextView display = findViewById(R.id.status);
            final EditText re = findViewById(R.id.editText);
            Button gue = findViewById(R.id.assume);

            gue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String as = re.getText().toString();
                    re.setText("");
                    int assu = Integer.parseInt(as);
                    String ans1 = "Your guess is too high";
                    String ans2 = "Your guess is too low";
                    if(assu == rnd){
                        Intent a = new Intent(SecActivity.this, ThiActivity.class);
                        startActivity(a);

                    }
                    else if(assu > rnd){
                        display.setText(ans1);
                    }
                    else if(assu < rnd){
                        display.setText(ans2);
                    }

                }
            });
        }
}
