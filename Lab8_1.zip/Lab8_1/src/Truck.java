
public class Truck extends Car {
    
    private double M_weight,weight;

    public Truck(double gas, double efficiency,double M_weight,double weight) {
        super(gas, efficiency);
        this.M_weight = M_weight;
        this.weight = weight;
        if(weight>M_weight){
            this.weight = M_weight;
        }
    }
@Override
    public void drive(double distance){
        double usedGas = distance/getEfficiency();
        if(weight>=1&&weight<=10){
            usedGas=usedGas+((usedGas*10/100));
        }else if(weight>=11&&weight<=20){
            usedGas=usedGas+((usedGas*20/100));
            }else if (weight>20){
            usedGas=usedGas+((usedGas*30/100));
        }
        if(getGas()<usedGas){
                System.out.println("You cannot drive too far, please add gas");
        }else {
            setGas(getGas()-usedGas);
        }
    }
}